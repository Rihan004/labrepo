#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

void ascending_sort(int arr[30] , int n ){
    for(int i=0; i<n -1; i++){
        for(int j=0; j<n-1-i; j++){
            if(arr[j]>arr[j+1]){
                int temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }

    printf("\n Parent processing perfomed ascending sort  : \n");
    for(int i =0; i<n; i++){
        printf(" %d" , arr[i]);
    }

}

void decending_sort(int arr[30] , int n ){
    for(int i=0; i<n -1; i++){
        for(int j=0; j<n-1-i; j++){
            if(arr[j]<arr[j+1]){
                int temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }

    printf("\n Child processing perfomed Decending sort  : \n");
    for(int i =0; i<n; i++){
        printf(" %d" , arr[i]);
    }

}

int main(){
    int n;
    printf("\n Enter number of elements you want to add : ");
    scanf("%d" , &n);
    int arr[n];
    printf("\n Enter numbers : ");
    for(int i=0; i<n; i++){
        scanf("%d" , &arr[i]);
    }

    if(fork() == 0){
         printf("\n Child process id:  %d " , getpid());
         decending_sort(arr , n);
    }else{
        wait(NULL);
        printf("\n Parent process id:  %d " , getppid());
        ascending_sort(arr , n);
    }

    return 0;
}


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
    pid_t pid = fork();

    if(pid == 0){
        sleep(3);
        printf("\n Parent process id : %d " ,getppid());
        printf("\n child process id : %d " ,getpid());
        printf("\n Child child process id : %d " ,pid );
        system("ps");
    }else{
        
        printf("\n Parent process id : %d " ,getppid());
        printf("\n Parent parent  process id : %d " ,getpid());
        printf("\n Parent child process id : %d " ,pid );

    }

    return 0;
}